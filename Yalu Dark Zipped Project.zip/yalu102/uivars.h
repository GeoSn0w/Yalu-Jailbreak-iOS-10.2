//
//  uivars.h
//  Yalu Dark Fork By GeoSn0w (@fce365)
//  Jailbreak by @qwertyoruiop and @marcograss
//
//  Created by GeoSn0w on 5/28/17.
//  Copyright © 2017 GeoSn0w. All rights reserved.
//

#import <UIKit/UIKit.h>

extern NSInteger nosubstrateplease; //Want beef?
extern NSInteger nosubstrateisactivenowwhat;
