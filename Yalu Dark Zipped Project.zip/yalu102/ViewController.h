//
//  ViewController.h
//  yalu102
//
//  Created by qwertyoruiop on 05/01/2017.
//  Copyright © 2017 kimjongcracks. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UIButton* dope;
}
- (IBAction)yolo:(id)sender;
@property (retain, nonatomic) IBOutlet UISwitch *ssh;
@property (retain, nonatomic) IBOutlet UIButton *fixcydia;
@property (retain, nonatomic) IBOutlet UILabel *iOSVer;
@property (retain, nonatomic) IBOutlet UILabel *certiftime;
@property (retain, nonatomic) IBOutlet UIButton *saveset;
@property (retain, nonatomic) IBOutlet UIButton *nosubstrate;
@property (retain, nonatomic) IBOutlet UISwitch *substrateswitch;
@property (retain, nonatomic) IBOutlet UIButton *fixespop;
@end

@interface fixes : UIViewController
{
    
}
@end

